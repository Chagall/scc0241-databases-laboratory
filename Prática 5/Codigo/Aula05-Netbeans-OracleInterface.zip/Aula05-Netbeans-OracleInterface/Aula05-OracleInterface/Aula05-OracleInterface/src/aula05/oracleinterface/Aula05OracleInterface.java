/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package aula05.oracleinterface;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

/**
 *
 * @author junio
 */
public class Aula05OracleInterface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JanelaPrincipal j = new JanelaPrincipal();
        j.ExibeJanelaPrincipal();
    }
}
